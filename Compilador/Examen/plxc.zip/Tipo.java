
public class Tipo {
	final static int NULL=0;
	final static int INT=1;
	final static int DOUBLE=2;
	final static int ARRAY=3;
	final static int PUNTERO=4;
	final static int CHAR=5;
}
