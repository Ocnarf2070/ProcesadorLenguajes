public class EtiquetaDoble{

	private String v;
	private String f;

	public EtiquetaDoble(String v, String f){
		this.v = v;
		this.f = f;
	}

	public String v(){
		return this.v;
	}

	public String f(){
		return this.f;
	}

	public void setV(String v){
		this.v = v;
	}
	
	public void setF(String f){
		this.f = f;
	}
}