public class If{
	public static final int GT = 1;
	public static final int LT = 2;
	public static final int EQ = 3;
	public static final int LTE = 4;
	public static final int GTE = 5;
	public static final int NEQ = 6;

}