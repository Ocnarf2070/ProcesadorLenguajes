#!/bin/bash

cup JPLC.cup 
jflex JPLC.flex
javac *.java
