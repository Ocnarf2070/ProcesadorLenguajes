#!/bin/bash

cup PLXC.cup 
jflex PLXC.flex
javac *.java
